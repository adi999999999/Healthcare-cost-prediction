# HealthCost AI — Project Assets & Design Specifications

## Theme & Color System
HealthCost AI utilizes a medical informatics design system built for clinical clarity, accessibility, and modern aesthetics:

| Token | Hex Code | Purpose |
| :--- | :--- | :--- |
| **Navy Dark** | `#0f2b48` | Primary brand headers, typography, navigation accents |
| **Navy Light** | `#1e3a8a` | Gradient accents, primary card backgrounds |
| **Teal Accent** | `#0d9488` | Interactive highlights, success states, positive metric pills |
| **Sky Blue** | `#0284c7` | Charts, data density histograms, secondary indicators |
| **Coral Red** | `#e11d48` | Risk warnings, smoker indicators, negative SHAP contributions |
| **Slate Gray** | `#64748b` | Subheadings, caption text, borders, and disclaimers |
| **Clean White** | `#ffffff` | Card containers and high-contrast content panes |

## Visual Architecture
All visualizations are generated using **Matplotlib** and **Seaborn** configured with consistent dpi, clean axis styling, and custom brand palettes.
- High-contrast text labels
- Desaturated grid lines for non-intrusive readability
- Clear legends with formatted currency prefixes
