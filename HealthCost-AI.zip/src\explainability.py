"""
HealthCost AI - Explainable AI (XAI) Module
Computes global and local feature contributions using SHAP (SHapley Additive exPlanations).
Provides publication-quality visualizations and plain-English factor breakdowns.
"""

import os
import sys
from typing import Dict, Any, List, Tuple
import joblib
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")  # Non-interactive backend
import matplotlib.pyplot as plt
import shap

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.data_preprocessing import (
    load_dataset,
    get_transformed_feature_names,
    ALL_FEATURE_COLUMNS
)

# Friendly display names for transformed features
FRIENDLY_NAMES: Dict[str, str] = {
    "age": "Age (Years)",
    "bmi": "Body Mass Index (BMI)",
    "children": "Number of Children",
    "sex_male": "Sex: Male",
    "smoker_yes": "Smoker Status: Yes",
    "region_northwest": "Region: Northwest",
    "region_southeast": "Region: Southeast",
    "region_southwest": "Region: Southwest"
}

_EXPLAINER_CACHE = None
_BACKGROUND_DATA_CACHE = None


def get_tree_explainer(model_path: str = "models/best_model.joblib"):
    """
    Retrieves or initializes a cached SHAP TreeExplainer for the trained ensemble model.
    """
    global _EXPLAINER_CACHE, _BACKGROUND_DATA_CACHE
    
    if _EXPLAINER_CACHE is not None:
        return _EXPLAINER_CACHE
        
    pipeline = joblib.load(model_path)
    preprocessor = pipeline.named_steps["preprocessor"]
    regressor = pipeline.named_steps["regressor"]
    
    # Check if model supports TreeExplainer
    try:
        explainer = shap.TreeExplainer(regressor)
    except Exception:
        # Fallback to KernelExplainer or sample-based explainer
        df = load_dataset()
        X_sample = preprocessor.transform(df[ALL_FEATURE_COLUMNS].head(100))
        explainer = shap.Explainer(regressor.predict, X_sample)
        
    _EXPLAINER_CACHE = explainer
    return _EXPLAINER_CACHE


def explain_global_importance(
    model_path: str = "models/best_model.joblib",
    sample_size: int = 300
) -> Tuple[pd.DataFrame, plt.Figure]:
    """
    Calculates global feature importance across dataset samples using mean |SHAP value|.
    
    Returns:
        Tuple: (DataFrame of ranked features, Matplotlib Figure)
    """
    pipeline = joblib.load(model_path)
    preprocessor = pipeline.named_steps["preprocessor"]
    feature_names = get_transformed_feature_names(preprocessor)
    
    df = load_dataset()
    sample_df = df.sample(min(sample_size, len(df)), random_state=42)
    X_proc = preprocessor.transform(sample_df[ALL_FEATURE_COLUMNS])
    
    explainer = get_tree_explainer(model_path)
    shap_vals = explainer.shap_values(X_proc)
    
    # Calculate mean absolute SHAP value for each feature
    mean_abs_shap = np.mean(np.abs(shap_vals), axis=0)
    
    summary_df = pd.DataFrame({
        "feature_raw": feature_names,
        "feature_label": [FRIENDLY_NAMES.get(f, f) for f in feature_names],
        "mean_abs_shap": mean_abs_shap
    }).sort_values(by="mean_abs_shap", ascending=True).reset_index(drop=True)
    
    # Create polished horizontal bar chart
    fig, ax = plt.subplots(figsize=(8.5, 4.8), dpi=150)
    colors = ["#0284c7" if f != "smoker_yes" else "#e11d48" for f in summary_df["feature_raw"]]
    
    bars = ax.barh(summary_df["feature_label"], summary_df["mean_abs_shap"], color=colors, height=0.65)
    
    ax.set_title("Global Feature Importance (Mean |SHAP Value|)", fontsize=13, fontweight="bold", pad=12, color="#0f2b48")
    ax.set_xlabel("Average Impact on Predicted Charge (USD $)", fontsize=10, labelpad=8, color="#334155")
    ax.grid(axis="x", linestyle="--", alpha=0.35)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#cbd5e1")
    ax.spines["bottom"].set_color("#cbd5e1")
    ax.tick_params(colors="#334155")
    
    # Add data labels
    for bar in bars:
        width = bar.get_width()
        ax.text(width + 50, bar.get_y() + bar.get_height() / 2, f"${width:,.0f}",
                va="center", ha="left", fontsize=9, fontweight="600", color="#1e293b")
                
    plt.tight_layout()
    return summary_df.sort_values(by="mean_abs_shap", ascending=False).reset_index(drop=True), fig


def explain_single_prediction(
    input_data: Dict[str, Any],
    model_path: str = "models/best_model.joblib"
) -> Dict[str, Any]:
    """
    Generates local SHAP explanation for an individual prediction instance.
    Breaks down which features increased or reduced the predicted insurance charge.
    
    Args:
        input_data: Beneficiary feature dictionary.
        model_path: Path to model pipeline.
        
    Returns:
        Dict: Detailed local explanation with base value, contributions, figure, and summary.
    """
    pipeline = joblib.load(model_path)
    preprocessor = pipeline.named_steps["preprocessor"]
    feature_names = get_transformed_feature_names(preprocessor)
    
    df_single = pd.DataFrame([input_data])[ALL_FEATURE_COLUMNS]
    X_single_proc = preprocessor.transform(df_single)
    
    explainer = get_tree_explainer(model_path)
    shap_vals = explainer.shap_values(X_single_proc)[0]
    
    base_val = float(explainer.expected_value[0] if isinstance(explainer.expected_value, (list, np.ndarray)) else explainer.expected_value)
    final_pred = float(pipeline.predict(df_single)[0])
    
    contributions = []
    for raw_name, val in zip(feature_names, shap_vals):
        contributions.append({
            "feature_raw": raw_name,
            "feature_label": FRIENDLY_NAMES.get(raw_name, raw_name),
            "shap_value": round(float(val), 2),
            "abs_impact": round(float(abs(val)), 2),
            "effect": "Increases Charge" if val > 0 else ("Decreases Charge" if val < 0 else "Neutral")
        })
        
    contributions_df = pd.DataFrame(contributions).sort_values(by="abs_impact", ascending=False).reset_index(drop=True)
    
    # Create local contribution diverging bar chart
    plot_df = pd.DataFrame(contributions).sort_values(by="shap_value", ascending=True)
    fig, ax = plt.subplots(figsize=(8.5, 4.5), dpi=150)
    
    bar_colors = ["#10b981" if v < 0 else "#ef4444" for v in plot_df["shap_value"]]
    bars = ax.barh(plot_df["feature_label"], plot_df["shap_value"], color=bar_colors, height=0.6)
    
    ax.axvline(0, color="#64748b", linewidth=1.2, linestyle="-")
    ax.set_title(
        f"Local Feature Contributions (Base: ${base_val:,.0f} → Predicted: ${final_pred:,.0f})",
        fontsize=12,
        fontweight="bold",
        pad=12,
        color="#0f2b48"
    )
    ax.set_xlabel("Contribution to Predicted Charge (USD $)", fontsize=10, labelpad=8, color="#334155")
    ax.grid(axis="x", linestyle="--", alpha=0.35)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_color("#cbd5e1")
    ax.spines["bottom"].set_color("#cbd5e1")
    ax.tick_params(colors="#334155")
    
    # Add values text
    for bar in bars:
        width = bar.get_width()
        offset = 50 if width >= 0 else -50
        ha = "left" if width >= 0 else "right"
        sign = "+" if width > 0 else ""
        ax.text(width + offset, bar.get_y() + bar.get_height() / 2, f"{sign}${width:,.0f}",
                va="center", ha=ha, fontsize=8.5, fontweight="600", color="#1e293b")
                
    plt.tight_layout()
    
    # Separate top positive and negative drivers
    top_positives = [c for c in contributions if c["shap_value"] > 50]
    top_negatives = [c for c in contributions if c["shap_value"] < -50]
    
    top_positives.sort(key=lambda x: x["shap_value"], reverse=True)
    top_negatives.sort(key=lambda x: x["shap_value"])
    
    return {
        "base_value": round(base_val, 2),
        "predicted_value": round(final_pred, 2),
        "contributions_df": contributions_df,
        "figure": fig,
        "top_positive_factors": top_positives[:3],
        "top_negative_factors": top_negatives[:3],
        "causality_disclaimer": (
            "Note: SHAP feature attributions reflect statistical associations learned by the machine learning "
            "model from historical data. They explain model behavior and should not be construed as clinical or causal proof."
        )
    }
