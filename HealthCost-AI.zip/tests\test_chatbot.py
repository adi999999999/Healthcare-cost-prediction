"""
Unit tests for chatbot context injection, guardrails, and offline analytical mode.
"""

import pytest
from src.llm_chatbot import (
    build_context_block,
    get_offline_fallback_response,
    generate_chat_response
)


def test_build_context_block():
    mock_prediction = {
        "sanitized_input": {"age": 40, "sex": "male", "bmi": 26.0, "children": 0, "smoker": "no", "region": "northeast"},
        "predicted_charge": 6500.50,
        "lower_bound": 4084.43,
        "upper_bound": 8916.57,
        "bmi_category": "Overweight"
    }
    
    mock_metrics = {
        "best_model_name": "Random Forest Regressor",
        "models": {
            "Random Forest Regressor": {"mae": 2416.07, "rmse": 4248.80, "r2": 0.9018}
        }
    }
    
    context = build_context_block(current_prediction=mock_prediction, model_metrics=mock_metrics)
    assert "Active User Profile" in context
    assert "Random Forest Regressor" in context
    assert "$6,500.50" in context
    assert "0.9018" in context


def test_get_offline_fallback_response_metrics():
    resp = get_offline_fallback_response("What does MAE mean?")
    assert "Mean Absolute Error" in resp or "MAE" in resp
    assert "2,416" in resp


def test_get_offline_fallback_response_prediction():
    mock_prediction = {
        "sanitized_input": {"age": 40, "sex": "male", "bmi": 32.0, "children": 0, "smoker": "yes", "region": "southeast"},
        "predicted_charge": 38500.00,
        "lower_bound": 36084.0,
        "upper_bound": 40916.0,
        "bmi_category": "Obese (High Risk)"
    }
    resp = get_offline_fallback_response("Why is my predicted charge high?", current_prediction=mock_prediction)
    assert "Smoking Status" in resp
    assert "38,500" in resp


def test_generate_chat_response_without_key():
    messages = [{"role": "user", "content": "Summarize the dataset findings"}]
    # Calling with empty key should safely return offline grounded response without error
    resp = generate_chat_response(messages=messages, api_key="")
    assert resp is not None
    assert len(resp) > 50
    assert "Dataset Insights" in resp or "smoker" in resp.lower()
