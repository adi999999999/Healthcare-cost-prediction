"""
HealthCost AI - LLM Chatbot Integration Module
Provides context-aware conversational AI assistant powered by OpenAI API
with strict guardrails, context injection, and graceful fallback modes.
"""

import os
import json
from typing import Dict, Any, List, Optional
from dotenv import load_dotenv

# Load local environment variables if available
load_dotenv()

SYSTEM_PROMPT_TEMPLATE = """You are HealthCost AI, an intelligent, empathetic, and scientifically rigorous healthcare analytics assistant.
You help non-technical users and data science recruiters understand machine learning predictions, explainable AI (SHAP) attributions, dataset patterns, and regression performance metrics.

=== CURRENT APPLICATION CONTEXT ===
{context_block}

=== CORE ASSISTANT GUIDELINES ===
1. EXPLAIN IN SIMPLE, BEGINNER-FRIENDLY TERMS:
   - Avoid unexplained jargon. When explaining metrics like MAE, explain it as the average dollar margin of error.
   - When explaining R², explain it as the percentage of price variation captured by the model.

2. GROUNDING & NO HALLUCINATIONS:
   - Only cite numbers, predictions, metrics, and feature contributions that match the provided context or verified dataset statistics.
   - Clearly distinguish between:
     a) Measured historical dataset statistics (e.g. median $9,382, smoker average $32,050).
     b) Model predictions for hypothetical profiles (e.g. estimated charge).
     c) General background knowledge.

3. STRICT CAUSALITY & MEDICAL GUARDRAILS:
   - NEVER claim correlation implies causation. SHAP values indicate statistical patterns learned from historical data, not biological causation.
   - NEVER provide medical diagnoses, treatment advice, or personal health prescriptions.
   - Always state that predictions are statistical estimates from a Machine Learning model, not formal insurance quotes or underwriting contracts.

4. TONE & FORMAT:
   - Professional, warm, structured with bullet points and bold highlights where helpful.
   - Keep answers focused, insightful, and concise.
"""


def build_context_block(
    current_prediction: Optional[Dict[str, Any]] = None,
    shap_explanation: Optional[Dict[str, Any]] = None,
    model_metrics: Optional[Dict[str, Any]] = None,
    dataset_kpis: Optional[Dict[str, Any]] = None
) -> str:
    """
    Constructs a structured context string from live application state to inject into LLM prompt.
    """
    parts = []
    
    if current_prediction:
        inp = current_prediction.get("sanitized_input", {})
        parts.append(
            f"Active User Profile: Age={inp.get('age')}, Sex={inp.get('sex')}, BMI={inp.get('bmi')} "
            f"({current_prediction.get('bmi_category')}), Children={inp.get('children')}, "
            f"Smoker={inp.get('smoker')}, Region={inp.get('region')}."
        )
        parts.append(
            f"Current Model Prediction: ${current_prediction.get('predicted_charge', 0):,.2f} USD "
            f"(Estimated Range: ${current_prediction.get('lower_bound', 0):,.2f} to ${current_prediction.get('upper_bound', 0):,.2f})."
        )
        
    if shap_explanation:
        pos_factors = shap_explanation.get("top_positive_factors", [])
        neg_factors = shap_explanation.get("top_negative_factors", [])
        base_val = shap_explanation.get("base_value", 13018.68)
        
        pos_str = ", ".join([f"{f['feature_label']} (+${f['shap_value']:,.0f})" for f in pos_factors]) if pos_factors else "None"
        neg_str = ", ".join([f"{f['feature_label']} (-${abs(f['shap_value']):,.0f})" for f in neg_factors]) if neg_factors else "None"
        
        parts.append(
            f"SHAP Attribution: Base Population Baseline = ${base_val:,.2f}.\n"
            f"Factors Increasing Charge: {pos_str}.\n"
            f"Factors Decreasing Charge: {neg_str}."
        )
        
    if model_metrics:
        best_name = model_metrics.get("best_model_name", "Random Forest Regressor")
        models_data = model_metrics.get("models", {})
        best_stats = models_data.get(best_name, {})
        parts.append(
            f"Deployed Model: {best_name} | Held-out Test Performance: MAE = ${best_stats.get('mae', 2416.07):,.2f}, "
            f"RMSE = ${best_stats.get('rmse', 4248.80):,.2f}, R² Score = {best_stats.get('r2', 0.9018):.4f}."
        )
        
    if dataset_kpis:
        parts.append(
            f"Dataset Verified Benchmarks (1,338 records): Overall Mean = ${dataset_kpis.get('mean_charge', 13270.42):,.2f}, "
            f"Median = ${dataset_kpis.get('median_charge', 9382.03):,.2f}. Smokers average ${dataset_kpis.get('smoker_mean_charge', 32050.23):,.2f} "
            f"(~{dataset_kpis.get('smoker_multiplier', 3.8)}x higher) vs non-smokers ${dataset_kpis.get('nonsmoker_mean_charge', 8434.27):,.2f}."
        )
        
    return "\n".join(parts) if parts else "No active prediction loaded. General health insurance analytics mode."


def get_offline_fallback_response(
    user_query: str,
    current_prediction: Optional[Dict[str, Any]] = None,
    shap_explanation: Optional[Dict[str, Any]] = None,
    model_metrics: Optional[Dict[str, Any]] = None,
    dataset_kpis: Optional[Dict[str, Any]] = None
) -> str:
    """
    Provides intelligent, grounded analytical answers when no OpenAI API key is configured.
    Guarantees the user is never stranded with a broken chat experience.
    """
    q = user_query.lower()
    
    # 1. Explain prediction
    if any(k in q for k in ["explain my prediction", "why is my predicted", "why is the charge", "how did you calculate"]):
        if not current_prediction:
            return (
                "**No profile is currently active.** Please head to the **Predict Insurance Charges** tab, "
                "input patient features, and click 'Calculate Predicted Charges'. I can then break down your exact estimate!"
            )
        
        pred = current_prediction.get("predicted_charge", 0)
        inp = current_prediction.get("sanitized_input", {})
        bmi_cat = current_prediction.get("bmi_category", "Normal")
        
        reasons = []
        if inp.get("smoker") == "yes":
            reasons.append("• **Smoking Status:** Smoking is the heaviest upward driver in this dataset, pushing charges up by $15,000–$25,000 above the average.")
        else:
            reasons.append("• **Non-Smoker:** As a non-smoker, you benefit from the baseline non-smoker pool (average ~$8,434).")
            
        if inp.get("bmi", 25) >= 30:
            reasons.append(f"• **Elevated BMI ({inp.get('bmi')} - {bmi_cat}):** In this dataset, BMIs above 30 have a strong compounding association with higher claims, especially when combined with smoking.")
        else:
            reasons.append(f"• **Healthy BMI ({inp.get('bmi')} - {bmi_cat}):** Keeps expected medical claims lower.")
            
        if inp.get("age", 30) > 45:
            reasons.append(f"• **Age ({inp.get('age')} years):** Charges show a steady upward trend with advancing age due to cumulative health risks.")
            
        drivers_text = "\n".join(reasons)
        return (
            f"### Prediction Breakdown: **${pred:,.2f} USD**\n\n"
            f"Here is why the model estimated this charge for a {inp.get('age')}-year-old {inp.get('sex')} "
            f"with a BMI of {inp.get('bmi')} ({bmi_cat}):\n\n"
            f"{drivers_text}\n\n"
            f"> **Statistical Range:** Expected interval between **${current_prediction.get('lower_bound', 0):,.2f}** "
            f"and **${current_prediction.get('upper_bound', 0):,.2f}** based on the model's test MAE.\n\n"
            f"*To enable natural conversational responses, configure your `OPENAI_API_KEY` in the sidebar or `.env`.*"
        )
        
    # 2. Factors / SHAP
    elif any(k in q for k in ["factor", "important", "shap", "influence", "drivers"]):
        if shap_explanation:
            pos = shap_explanation.get("top_positive_factors", [])
            neg = shap_explanation.get("top_negative_factors", [])
            pos_text = "\n".join([f"• **{f['feature_label']}**: +${f['shap_value']:,.2f}" for f in pos]) or "• None"
            neg_text = "\n".join([f"• **{f['feature_label']}**: -${abs(f['shap_value']):,.2f}" for f in neg]) or "• None"
            return (
                f"### Key Influencing Factors (SHAP Analysis)\n\n"
                f"SHAP decomposes how much each feature adjusted the estimate away from the population baseline (${shap_explanation.get('base_value', 13018):,.2f}):\n\n"
                f"**Features Increasing Your Charge:**\n{pos_text}\n\n"
                f"**Features Decreasing Your Charge:**\n{neg_text}\n\n"
                f"> **Important:** These values describe model feature attributions, not direct medical causation."
            )
        else:
            return (
                "Across the entire dataset, the top 3 global factors are:\n"
                "1. **Smoking Status:** Accounts for over 60% of variance.\n"
                "2. **Body Mass Index (BMI):** Strongest impact when BMI > 30.\n"
                "3. **Age:** Adds ~$250–$300 in annual charges for every additional year."
            )
            
    # 3. Model performance / MAE / RMSE / R2
    elif any(k in q for k in ["mae", "rmse", "r2", "r-squared", "model", "performance", "best"]):
        return (
            "### Model Evaluation & Metrics Summary\n\n"
            "We trained and tested 3 models on a held-out 20% test partition (268 unseen patient records):\n\n"
            "1. **Random Forest Regressor (Selected Best Model):**\n"
            "   - **MAE:** **$2,416.07** (On average, predictions are off by ~$2,416)\n"
            "   - **RMSE:** **$4,248.80** (Penalizes larger outliers)\n"
            "   - **R² Score:** **0.9018** (Captures **90.2%** of all variation in insurance charges)\n"
            "2. **Gradient Boosting Regressor:** MAE = $2,517.47 | R² = 0.9009\n"
            "3. **Linear Regression:** MAE = $4,177.05 | R² = 0.8069\n\n"
            "Random Forest won because its ensemble of decision trees effectively captures non-linear interactions like `Smoker × Obese BMI`."
        )
        
    # 4. Dataset findings / summary
    elif any(k in q for k in ["dataset", "summary", "findings", "insight", "statistics"]):
        return (
            "### Verified Dataset Insights (1,338 Insurance Records)\n\n"
            "• **Total Sample Size:** 1,338 records (deduplicated to 1,337 unique rows).\n"
            "• **Charges Distribution:** Heavily right-skewed. Median = **$9,382.03**, Mean = **$13,270.42**, Max = **$63,770.43**.\n"
            "• **The Smoking Multiplier:** Smokers average **$32,050.23** (~3.8x higher) compared to **$8,434.27** for non-smokers.\n"
            "• **Obesity Compound Effect:** Obese smokers (BMI ≥ 30) average **$41,355.87**, while obese non-smokers average only **$8,809.55**.\n"
            "• **Demographics:** Age spans 18 to 64; 50.5% male / 49.5% female; four US geographic regions evenly represented."
        )
        
    # 5. Default guided response
    else:
        return (
            f"I received your question: *\"{user_query}\"*\n\n"
            f"Here are quick answers you can explore right now:\n"
            f"- **'Explain my prediction'**: Breaks down the active profile's estimated charge.\n"
            f"- **'What are the most important factors?'**: Shows SHAP contributions.\n"
            f"- **'Explain the model performance'**: Details MAE, RMSE, and R² scores.\n"
            f"- **'Summarize the dataset findings'**: Key domain takeaways.\n\n"
            f"*(To unlock full conversational AI powered by OpenAI, enter your API key in the sidebar)*"
        )


def generate_chat_response(
    messages: List[Dict[str, str]],
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    model_name: Optional[str] = None,
    current_prediction: Optional[Dict[str, Any]] = None,
    shap_explanation: Optional[Dict[str, Any]] = None,
    model_metrics: Optional[Dict[str, Any]] = None,
    dataset_kpis: Optional[Dict[str, Any]] = None
) -> str:
    """
    Generates a conversational response.
    Connects to the OpenAI API when an API key is available,
    and falls back to intelligent, grounded local analysis when no key is present.
    
    Args:
        messages: Full conversation history [{"role": "user"|"assistant", "content": ...}].
        api_key: Optional API key.
        base_url: Optional custom base URL.
        model_name: Optional LLM model identifier.
        current_prediction: Live prediction context.
        shap_explanation: Live SHAP explanation context.
        model_metrics: Model performance metrics.
        dataset_kpis: Verified dataset statistics.
        
    Returns:
        str: Assistant response message.
    """
    effective_api_key = api_key or os.getenv("OPENAI_API_KEY", "").strip()
    effective_model = model_name or os.getenv("OPENAI_MODEL_NAME", "gpt-4o-mini").strip()
    effective_base_url = base_url or os.getenv("OPENAI_BASE_URL", None)
    
    latest_user_query = messages[-1]["content"] if messages else ""
    
    # If no API key provided, execute the offline grounded analytical engine
    if not effective_api_key or effective_api_key == "your_openai_api_key_here":
        return get_offline_fallback_response(
            user_query=latest_user_query,
            current_prediction=current_prediction,
            shap_explanation=shap_explanation,
            model_metrics=model_metrics,
            dataset_kpis=dataset_kpis
        )
        
    # Real OpenAI API call
    try:
        from openai import OpenAI
        
        client_kwargs = {"api_key": effective_api_key}
        if effective_base_url:
            client_kwargs["base_url"] = effective_base_url
            
        client = OpenAI(**client_kwargs)
        
        # Build dynamic context block
        context_block = build_context_block(
            current_prediction=current_prediction,
            shap_explanation=shap_explanation,
            model_metrics=model_metrics,
            dataset_kpis=dataset_kpis
        )
        
        system_prompt = SYSTEM_PROMPT_TEMPLATE.format(context_block=context_block)
        
        # Assemble message payload with system prompt first, then recent conversation history
        # (limit history to last 10 turns to conserve context window)
        api_messages = [{"role": "system", "content": system_prompt}]
        for m in messages[-10:]:
            api_messages.append({"role": m["role"], "content": m["content"]})
            
        completion = client.chat.completions.create(
            model=effective_model,
            messages=api_messages,
            temperature=0.3,
            max_tokens=650
        )
        
        return completion.choices[0].message.content.strip()
        
    except Exception as e:
        err_msg = str(e)
        # Handle specific error classes gracefully
        if "AuthenticationError" in err_msg or "invalid_api_key" in err_msg or "Incorrect API key" in err_msg:
            return (
                "⚠️ **Authentication Error:** The provided OpenAI API key appears to be invalid. "
                "Please check the key in the sidebar or `.env` file.\n\n"
                "In the meantime, here is the analytical summary:\n\n" +
                get_offline_fallback_response(
                    user_query=latest_user_query,
                    current_prediction=current_prediction,
                    shap_explanation=shap_explanation,
                    model_metrics=model_metrics,
                    dataset_kpis=dataset_kpis
                )
            )
        elif "RateLimitError" in err_msg:
            return (
                "⚠️ **Rate Limit Reached:** OpenAI rate limit exceeded. Please wait a moment and retry.\n\n" +
                get_offline_fallback_response(
                    user_query=latest_user_query,
                    current_prediction=current_prediction,
                    shap_explanation=shap_explanation,
                    model_metrics=model_metrics,
                    dataset_kpis=dataset_kpis
                )
            )
        else:
            return (
                f"⚠️ **LLM Connection Note:** Could not reach the LLM API ({err_msg}).\n\n"
                "Falling back to verified local analytical engine:\n\n" +
                get_offline_fallback_response(
                    user_query=latest_user_query,
                    current_prediction=current_prediction,
                    shap_explanation=shap_explanation,
                    model_metrics=model_metrics,
                    dataset_kpis=dataset_kpis
                )
            )
