"""
Unit tests for data loading, input validation, and preprocessing pipeline.
"""

import pytest
import pandas as pd
from src.data_preprocessing import (
    load_dataset,
    validate_input,
    calculate_bmi_category,
    get_preprocessor,
    get_transformed_feature_names,
    ALL_FEATURE_COLUMNS,
    TARGET_COLUMN
)


def test_load_dataset_valid():
    df = load_dataset("data/insurance.csv")
    assert not df.empty
    assert len(df) >= 1300
    for col in ALL_FEATURE_COLUMNS + [TARGET_COLUMN]:
        assert col in df.columns


def test_validate_input_valid():
    valid_data = {
        "age": 35,
        "sex": "female",
        "bmi": 24.5,
        "children": 2,
        "smoker": "no",
        "region": "southwest"
    }
    is_valid, err_msg, sanitized = validate_input(valid_data)
    assert is_valid is True
    assert err_msg == ""
    assert sanitized["age"] == 35
    assert sanitized["bmi"] == 24.5
    assert sanitized["sex"] == "female"


def test_validate_input_out_of_bounds():
    # Negative age
    is_valid, err, _ = validate_input({
        "age": -5, "sex": "male", "bmi": 25.0, "children": 0, "smoker": "no", "region": "northwest"
    })
    assert is_valid is False
    assert "age" in err.lower()

    # Extreme unrealistic BMI
    is_valid, err, _ = validate_input({
        "age": 30, "sex": "male", "bmi": 120.0, "children": 0, "smoker": "no", "region": "northwest"
    })
    assert is_valid is False
    assert "bmi" in err.lower()


def test_validate_input_invalid_category():
    # Invalid smoker option
    is_valid, err, _ = validate_input({
        "age": 30, "sex": "male", "bmi": 25.0, "children": 0, "smoker": "occasionally", "region": "northwest"
    })
    assert is_valid is False
    assert "smoker" in err.lower()

    # Invalid region
    is_valid, err, _ = validate_input({
        "age": 30, "sex": "male", "bmi": 25.0, "children": 0, "smoker": "no", "region": "midwest"
    })
    assert is_valid is False
    assert "region" in err.lower()


def test_calculate_bmi_category():
    assert calculate_bmi_category(17.5)[0] == "Underweight"
    assert calculate_bmi_category(22.0)[0] == "Normal Weight"
    assert calculate_bmi_category(27.5)[0] == "Overweight"
    assert "Obese" in calculate_bmi_category(34.2)[0]


def test_preprocessor_transformation():
    preprocessor = get_preprocessor()
    df = load_dataset("data/insurance.csv").head(10)
    X = df[ALL_FEATURE_COLUMNS]
    transformed = preprocessor.fit_transform(X)
    
    # 3 numerical + 1 sex (male) + 1 smoker (yes) + 3 regions = 8 features
    assert transformed.shape == (10, 8)
    names = get_transformed_feature_names(preprocessor)
    assert len(names) == 8
    assert "smoker_yes" in names
