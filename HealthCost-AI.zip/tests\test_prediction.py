"""
Unit tests for model inference and comparative profile analysis.
"""

import pytest
from src.predict import (
    load_prediction_pipeline,
    predict_charge,
    compare_two_profiles
)


def test_load_prediction_pipeline():
    pipeline = load_prediction_pipeline("models/best_model.joblib")
    assert pipeline is not None
    assert hasattr(pipeline, "predict")


def test_predict_charge_valid():
    profile = {
        "age": 45,
        "sex": "male",
        "bmi": 28.0,
        "children": 1,
        "smoker": "no",
        "region": "southeast"
    }
    result = predict_charge(profile, model_path="models/best_model.joblib")
    
    assert "predicted_charge" in result
    assert result["predicted_charge"] > 1000.0
    assert result["currency"] == "USD"
    assert result["lower_bound"] <= result["predicted_charge"]
    assert result["upper_bound"] >= result["predicted_charge"]
    assert "disclaimer" in result


def test_compare_two_profiles():
    # Non-smoker vs smoker
    profile_a = {
        "age": 30, "sex": "male", "bmi": 25.0, "children": 0, "smoker": "no", "region": "northwest"
    }
    profile_b = {
        "age": 30, "sex": "male", "bmi": 25.0, "children": 0, "smoker": "yes", "region": "northwest"
    }
    
    comp = compare_two_profiles(profile_a, profile_b, model_path="models/best_model.joblib")
    
    assert comp["higher_profile"] == "Profile B"
    assert comp["charge_difference_usd"] > 5000.0
    assert "smoker" in comp["differing_features"]
    assert comp["differing_features"]["smoker"]["profile_a"] == "no"
    assert comp["differing_features"]["smoker"]["profile_b"] == "yes"
