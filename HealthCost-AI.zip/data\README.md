# Medical Insurance Cost Dataset

## Source & Overview
The dataset used in **HealthCost AI** is the standard benchmark **Medical Insurance Cost Dataset** (originally featured in Brett Lantz's *Machine Learning with R*, Packt Publishing). It captures demographic and health risk attributes alongside annual medical insurance charges billed to health insurance providers in the United States.

## Dataset Specifications
- **Total Records:** 1,338 rows (1,337 unique after deduplicating 1 identical record)
- **Features:** 6 input features + 1 target variable (`charges`)
- **Missing Values:** 0 missing values across all features
- **Target Variable:** `charges` (float64) — Individual medical costs billed by health insurance in US Dollars (USD).

## Feature Dictionary

| Feature | Data Type | Range / Categories | Description & Units |
| :--- | :--- | :--- | :--- |
| `age` | Integer | 18 – 64 | Primary beneficiary age in years. |
| `sex` | String / Categorical | `female`, `male` | Insurance contractor biological sex. |
| `bmi` | Float | 15.96 – 53.13 | Body Mass Index ($kg / m^2$). Normal range: 18.5 - 24.9; Overweight: 25.0 - 29.9; Obese: $\ge 30.0$. |
| `children`| Integer | 0 – 5 | Number of children/dependents covered by health insurance. |
| `smoker` | String / Categorical | `yes`, `no` | Whether the beneficiary regularly smokes tobacco. |
| `region` | String / Categorical | `northeast`, `northwest`, `southeast`, `southwest` | Residential area of beneficiary in the US. |
| `charges`| Float (Target) | \$1,121.87 – \$63,770.43 | Annual medical insurance charges billed to the insurer (USD). |

## Key Empirical Findings
1. **Smoking Impact:** Smoking is the strongest single predictor of high insurance charges. Beneficiaries who smoke have an average charge of **\$32,050.23** compared to **\$8,434.27** for non-smokers (an increase of over 280%).
2. **BMI Interaction:** A strong non-linear interaction exists between BMI and smoking:
   - Non-smokers with BMI $\ge 30$ (obese) incur an average of **\$8,809.55**.
   - Smokers with BMI $\ge 30$ (obese) incur an average of **\$41,355.87** (nearly 5x increase!).
3. **Age Correlation:** Charges show a steady baseline increase with advancing age among non-smokers.
4. **Target Distribution:** Charges are strongly right-skewed (median = \$9,382.03, mean = \$13,270.42).

## Important Scope & Assumptions
- **Currency & Units:** All financial values are expressed in US Dollars (USD).
- **Insurance Charges vs Hospital Cost:** This dataset reflects *charges billed to the insurer*, not the hospital's internal operating costs, nor necessarily the patient's personal out-of-pocket copays.
- **Causality:** While high correlation exists between lifestyle factors (smoking, high BMI) and high insurance claims, machine learning predictions represent statistical associations rather than medical or causal certainty.
