"""
HealthCost AI - Data Preprocessing Module
Handles data loading, validation, feature separation, encoding, and scaling pipelines.
"""

from typing import Tuple, Dict, Any, List
import os
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler

# Canonical columns
NUMERICAL_FEATURES: List[str] = ["age", "bmi", "children"]
CATEGORICAL_FEATURES: List[str] = ["sex", "smoker", "region"]
ALL_FEATURE_COLUMNS: List[str] = NUMERICAL_FEATURES + CATEGORICAL_FEATURES
TARGET_COLUMN: str = "charges"

# Allowed category domains
ALLOWED_VALUES: Dict[str, List[str]] = {
    "sex": ["male", "female"],
    "smoker": ["yes", "no"],
    "region": ["northeast", "northwest", "southeast", "southwest"]
}

# Plausible numerical bounds for input validation
NUMERICAL_BOUNDS: Dict[str, Tuple[float, float]] = {
    "age": (18.0, 100.0),
    "bmi": (10.0, 65.0),
    "children": (0.0, 15.0)
}


def load_dataset(file_path: str = "data/insurance.csv", drop_duplicates: bool = True) -> pd.DataFrame:
    """
    Loads the insurance dataset from a CSV file.
    
    Args:
        file_path: Path to the insurance dataset CSV.
        drop_duplicates: Whether to drop duplicate rows (defaults to True).
        
    Returns:
        pd.DataFrame: Cleaned dataframe.
        
    Raises:
        FileNotFoundError: If the file does not exist at file_path.
        ValueError: If mandatory columns are missing.
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Dataset file not found at: {file_path}")
        
    df = pd.read_csv(file_path)
    
    # Verify required schema
    missing_cols = [c for c in ALL_FEATURE_COLUMNS + [TARGET_COLUMN] if c not in df.columns]
    if missing_cols:
        raise ValueError(f"Dataset is missing required columns: {missing_cols}")
        
    # Standardize string representations
    for col in CATEGORICAL_FEATURES:
        df[col] = df[col].astype(str).str.strip().str.lower()
        
    if drop_duplicates:
        df = df.drop_duplicates().reset_index(drop=True)
        
    return df


def get_preprocessor() -> ColumnTransformer:
    """
    Creates a reproducible ColumnTransformer for numerical scaling and categorical encoding.
    Uses drop='first' on OneHotEncoder to prevent multicollinearity in linear models.
    
    Returns:
        ColumnTransformer: Preprocessing transformer.
    """
    preprocessor = ColumnTransformer(
        transformers=[
            (
                "num",
                StandardScaler(),
                NUMERICAL_FEATURES
            ),
            (
                "cat",
                OneHotEncoder(drop="first", sparse_output=False, handle_unknown="ignore"),
                CATEGORICAL_FEATURES
            )
        ],
        remainder="drop"
    )
    return preprocessor


def get_transformed_feature_names(preprocessor: ColumnTransformer) -> List[str]:
    """
    Extracts the clean feature names resulting from ColumnTransformer.
    
    Args:
        preprocessor: A fitted ColumnTransformer.
        
    Returns:
        List[str]: List of transformed feature names.
    """
    names = list(NUMERICAL_FEATURES)
    cat_encoder = preprocessor.named_transformers_["cat"]
    cat_names = list(cat_encoder.get_feature_names_out(CATEGORICAL_FEATURES))
    return names + cat_names


def prepare_train_test_data(
    file_path: str = "data/insurance.csv",
    test_size: float = 0.2,
    random_state: int = 42
) -> Tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series]:
    """
    Loads dataset, splits into input features (X) and target (y), and performs train-test split.
    Guarantees no data leakage between train and test sets.
    
    Args:
        file_path: Path to dataset.
        test_size: Ratio of test partition (default: 0.2).
        random_state: Random state for reproducibility (default: 42).
        
    Returns:
        Tuple: (X_train, X_test, y_train, y_test)
    """
    df = load_dataset(file_path)
    X = df[ALL_FEATURE_COLUMNS].copy()
    y = df[TARGET_COLUMN].copy()
    
    return train_test_split(X, y, test_size=test_size, random_state=random_state)


def validate_input(input_data: Dict[str, Any]) -> Tuple[bool, str, Dict[str, Any]]:
    """
    Validates user input dictionary for inference.
    Checks data types, ranges, and categorical domains.
    
    Args:
        input_data: Dict containing patient/beneficiary features.
        
    Returns:
        Tuple[bool, str, Dict[str, Any]]: (is_valid, error_message, sanitized_data)
    """
    sanitized: Dict[str, Any] = {}
    
    # Check all required keys exist
    for feature in ALL_FEATURE_COLUMNS:
        if feature not in input_data:
            return False, f"Missing required feature: '{feature}'", {}
            
    # Validate numerical fields
    for col, (low, high) in NUMERICAL_BOUNDS.items():
        val = input_data[col]
        try:
            num_val = float(val)
        except (ValueError, TypeError):
            return False, f"Feature '{col}' must be a numerical value. Received: {val}", {}
            
        if num_val < low or num_val > high:
            return False, f"Feature '{col}' must be between {low} and {high}. Received: {num_val}", {}
            
        # Keep children and age as reasonable types
        sanitized[col] = int(num_val) if col in ["age", "children"] else round(num_val, 2)
        
    # Validate categorical fields
    for col, allowed in ALLOWED_VALUES.items():
        raw_val = str(input_data[col]).strip().lower()
        if raw_val not in allowed:
            return False, f"Feature '{col}' must be one of {allowed}. Received: '{raw_val}'", {}
        sanitized[col] = raw_val
        
    return True, "", sanitized


def calculate_bmi_category(bmi: float) -> Tuple[str, str]:
    """
    Classifies a BMI into standard WHO epidemiological weight categories.
    
    Args:
        bmi: Body mass index value.
        
    Returns:
        Tuple[str, str]: (Category Name, Status Color/Badge)
    """
    if bmi < 18.5:
        return "Underweight", "#3b82f6"  # Blue
    elif bmi < 25.0:
        return "Normal Weight", "#10b981"  # Green
    elif bmi < 30.0:
        return "Overweight", "#f59e0b"  # Amber
    else:
        return "Obese (High Risk)", "#ef4444"  # Red
