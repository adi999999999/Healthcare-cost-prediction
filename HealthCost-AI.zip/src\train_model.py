"""
HealthCost AI - Model Training Pipeline
Trains multiple regression models, evaluates them on a held-out test set,
selects the best model, and serializes trained pipelines and performance metrics.
"""

import os
import sys
import json
from typing import Dict, Any, Tuple
import joblib
import pandas as pd

# Ensure project root is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor, GradientBoostingRegressor

from src.data_preprocessing import (
    prepare_train_test_data,
    get_preprocessor,
    get_transformed_feature_names
)
from src.evaluate_model import calculate_metrics, compare_models_summary


def train_and_evaluate_all_models(
    data_path: str = "data/insurance.csv",
    output_dir: str = "models",
    test_size: float = 0.2,
    random_state: int = 42
) -> Tuple[Dict[str, Any], str]:
    """
    Executes full training pipeline for Linear Regression, Random Forest, and Gradient Boosting.
    Selects the best model based on held-out test evaluation.
    
    Args:
        data_path: Path to dataset.
        output_dir: Directory to save serialized artifacts.
        test_size: Held-out test split ratio.
        random_state: Seed for reproducibility.
        
    Returns:
        Tuple: (evaluation_results_dict, best_model_name)
    """
    os.makedirs(output_dir, exist_ok=True)
    
    print("Loading and partitioning dataset...")
    X_train, X_test, y_train, y_test = prepare_train_test_data(
        file_path=data_path,
        test_size=test_size,
        random_state=random_state
    )
    print(f"Train samples: {len(X_train)} | Test samples: {len(X_test)}")
    
    # Candidate models to evaluate
    model_candidates = {
        "Linear Regression": LinearRegression(),
        "Random Forest Regressor": RandomForestRegressor(
            n_estimators=100,
            max_depth=5,
            min_samples_split=4,
            random_state=random_state
        ),
        "Gradient Boosting Regressor": GradientBoostingRegressor(
            n_estimators=100,
            max_depth=3,
            learning_rate=0.1,
            random_state=random_state
        )
    }
    
    fitted_pipelines: Dict[str, Pipeline] = {}
    evaluation_results: Dict[str, Dict[str, float]] = {}
    test_predictions: Dict[str, list] = {}
    
    print("\n--- Training & Evaluating Models ---")
    for name, regressor in model_candidates.items():
        preprocessor = get_preprocessor()
        pipeline = Pipeline([
            ("preprocessor", preprocessor),
            ("regressor", regressor)
        ])
        
        # Fit pipeline strictly on train data
        pipeline.fit(X_train, y_train)
        
        # Evaluate on held-out test data
        y_pred = pipeline.predict(X_test)
        metrics = calculate_metrics(y_test.values, y_pred)
        
        fitted_pipelines[name] = pipeline
        evaluation_results[name] = metrics
        test_predictions[name] = y_pred.tolist()
        
        print(f"[{name}] MAE: ${metrics['mae']:,.2f} | RMSE: ${metrics['rmse']:,.2f} | R²: {metrics['r2']:.4f}")
        
        # Save individual model
        slug = name.lower().replace(" ", "_")
        joblib.dump(pipeline, os.path.join(output_dir, f"{slug}.joblib"))
        
    # Select best model based on R2 score (or lowest MAE if tied)
    best_model_name = max(evaluation_results, key=lambda k: (evaluation_results[k]["r2"], -evaluation_results[k]["mae"]))
    best_pipeline = fitted_pipelines[best_model_name]
    
    print(f"\n>>> Selected Best Model: {best_model_name} (R² = {evaluation_results[best_model_name]['r2']})")
    
    # Save best model separately
    best_model_path = os.path.join(output_dir, "best_model.joblib")
    joblib.dump(best_pipeline, best_model_path)
    
    # Save metadata and evaluation metrics to JSON
    metadata = {
        "best_model_name": best_model_name,
        "models": evaluation_results,
        "test_size": test_size,
        "random_state": random_state,
        "train_samples": len(X_train),
        "test_samples": len(X_test),
        "feature_names": get_transformed_feature_names(best_pipeline.named_steps["preprocessor"])
    }
    
    metrics_path = os.path.join(output_dir, "evaluation_metrics.json")
    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=4)
        
    # Save test actuals & predictions for dashboard residual plots
    test_eval_df = pd.DataFrame({
        "actual": y_test.values,
        **{f"pred_{m.lower().replace(' ', '_')}": test_predictions[m] for m in model_candidates}
    })
    test_eval_df.to_csv(os.path.join(output_dir, "test_eval_predictions.csv"), index=False)
    
    print(f"Artifacts successfully saved to '{output_dir}/'")
    return metadata, best_model_name


if __name__ == "__main__":
    train_and_evaluate_all_models()
