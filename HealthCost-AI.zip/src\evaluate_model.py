"""
HealthCost AI - Model Evaluation Module
Calculates regression evaluation metrics (MAE, RMSE, R²), residual statistics,
and provides beginner-friendly explanations.
"""

from typing import Dict, Any
import numpy as np
import pandas as pd
from sklearn.metrics import mean_absolute_error, root_mean_squared_error, r2_score


def calculate_metrics(y_true: np.ndarray, y_pred: np.ndarray) -> Dict[str, float]:
    """
    Computes key regression metrics: MAE, RMSE, and R2.
    
    Args:
        y_true: Array of actual ground-truth values.
        y_pred: Array of model predicted values.
        
    Returns:
        Dict[str, float]: Dictionary with mae, rmse, and r2.
    """
    mae = float(mean_absolute_error(y_true, y_pred))
    rmse = float(root_mean_squared_error(y_true, y_pred))
    r2 = float(r2_score(y_true, y_pred))
    
    return {
        "mae": round(mae, 2),
        "rmse": round(rmse, 2),
        "r2": round(r2, 4)
    }


def get_metric_explanations() -> Dict[str, Dict[str, str]]:
    """
    Provides beginner-friendly explanations of each regression metric.
    
    Returns:
        Dict: Comprehensive explanations with context and interpretation guidelines.
    """
    return {
        "MAE": {
            "name": "Mean Absolute Error (MAE)",
            "unit": "USD ($)",
            "explanation": (
                "On average, how many dollars the model's predictions miss the actual insurance charges. "
                "Because it treats all errors linearly, it is easy to interpret directly in dollar terms."
            ),
            "interpretation": "Lower is better. For example, an MAE of $2,415 means the prediction is off by ~$2,415 on average."
        },
        "RMSE": {
            "name": "Root Mean Squared Error (RMSE)",
            "unit": "USD ($)",
            "explanation": (
                "The square root of average squared differences. RMSE penalizes large errors much more heavily than MAE. "
                "If RMSE is significantly higher than MAE, it reveals that the model makes occasional very large prediction errors."
            ),
            "interpretation": "Lower is better. Measures sensitivity to severe outlier errors."
        },
        "R2": {
            "name": "R-squared Score (R²)",
            "unit": "Dimensionless (0.0 to 1.0)",
            "explanation": (
                "The coefficient of determination. It explains the proportion of total variance in medical charges "
                "that is successfully captured and predicted by the model's input features."
            ),
            "interpretation": "Higher is better. An R² of 0.90 means the model accounts for 90% of the variation in insurance charges."
        }
    }


def compare_models_summary(models_results: Dict[str, Dict[str, float]]) -> pd.DataFrame:
    """
    Formats multi-model evaluation results into a sorted comparative DataFrame.
    
    Args:
        models_results: Dictionary of {model_name: {'mae': ..., 'rmse': ..., 'r2': ...}}.
        
    Returns:
        pd.DataFrame: Formatted comparison table sorted by R² descending.
    """
    rows = []
    for model_name, metrics in models_results.items():
        rows.append({
            "Model Name": model_name,
            "MAE ($)": metrics["mae"],
            "RMSE ($)": metrics["rmse"],
            "R² Score": metrics["r2"]
        })
        
    df_comparison = pd.DataFrame(rows)
    df_comparison = df_comparison.sort_values(by="R² Score", ascending=False).reset_index(drop=True)
    return df_comparison
