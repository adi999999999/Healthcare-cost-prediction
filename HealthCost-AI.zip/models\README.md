# Machine Learning Models & Artifacts

## Overview
This directory stores the serialized scikit-learn pipelines and evaluation benchmarks for **HealthCost AI**. Every pipeline combines a reproducible `ColumnTransformer` (StandardScaler on continuous numerical features + OneHotEncoder on categorical features) and a supervised regression model.

## Model Benchmarks (Held-out Test Split: 20%, 268 samples)

| Model | MAE ($) | RMSE ($) | R² Score | Status |
| :--- | :--- | :--- | :--- | :--- |
| **Random Forest Regressor** | **\$2,416.07** | **\$4,248.80** | **0.9018** | **Selected Best Model** |
| **Gradient Boosting Regressor** | \$2,517.47 | \$4,268.28 | 0.9009 | Baseline Ensemble |
| **Linear Regression** | \$4,177.05 | \$5,956.34 | 0.8069 | Parametric Baseline |

## Artifacts Stored
- `best_model.joblib`: The winning pipeline (Random Forest Regressor) with fitted preprocessor.
- `random_forest.joblib`: Random Forest Regressor pipeline (`n_estimators=100, max_depth=5, min_samples_split=4`).
- `gradient_boosting.joblib`: Gradient Boosting Regressor pipeline (`n_estimators=100, max_depth=3, learning_rate=0.1`).
- `linear_regression.joblib`: Multiple Linear Regression pipeline (`StandardScaler + OneHotEncoder(drop='first')`).
- `evaluation_metrics.json`: JSON metadata recording test sample count, random seed, feature names, and evaluation scores.
- `test_eval_predictions.csv`: Held-out actual charges vs predictions across all models for residual and error visualization.

## How to Retrain Models
To retrain and regenerate all artifacts from scratch:
```bash
python src/train_model.py
```
