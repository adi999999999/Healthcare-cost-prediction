# 🩺 HealthCost AI — Intelligent Healthcare Cost Prediction & AI Assistant

[![Python Version](https://img.shields.io/badge/Python-3.10%20%7C%203.11%20%7C%203.12%20%7C%203.14-blue.svg)](https://www.python.org/)
[![Framework](https://img.shields.io/badge/App-Streamlit%201.66-FF4B4B.svg)](https://streamlit.io/)
[![Machine Learning](https://img.shields.io/badge/ML-Scikit--Learn-F7931E.svg)](https://scikit-learn.org/)
[![Explainable AI](https://img.shields.io/badge/XAI-SHAP-success.svg)](https://shap.readthedocs.io/)
[![LLM Assistant](https://img.shields.io/badge/LLM-OpenAI%20API-00A67E.svg)](https://openai.com/)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)

> **HealthCost AI** is an end-to-end, production-grade Machine Learning and Generative AI application that predicts individual healthcare insurance charges, visually uncovers empirical risk patterns, demystifies predictions using **Explainable AI (SHAP)**, and provides an **LLM-powered conversational assistant** that explains complex models, predictions, and metrics in simple, beginner-friendly language.

---

## 📑 Table of Contents
1. [Project Overview & Motivation](#1-project-overview--motivation)
2. [End-to-End System Architecture](#2-end-to-end-system-architecture)
3. [Technology Stack](#3-technology-stack)
4. [Dataset Specifications & Key Findings](#4-dataset-specifications--key-findings)
5. [Machine Learning Pipeline & Model Comparison](#5-machine-learning-pipeline--model-comparison)
6. [Explainable AI (SHAP Interpretability)](#6-explainable-ai-shap-interpretability)
7. [LLM-Powered Conversational AI Assistant](#7-llm-powered-conversational-ai-assistant)
8. [Interactive Dashboard Features](#8-interactive-dashboard-features)
9. [Project Directory Structure](#9-project-directory-structure)
10. [Installation & Quickstart Guide](#10-installation--quickstart-guide)
11. [Configuration & Environment Variables](#11-configuration--environment-variables)
12. [Automated Testing](#12-automated-testing)
13. [Limitations & Responsible AI Disclaimer](#13-limitations--responsible-ai-disclaimer)
14. [Future Roadmap](#14-future-roadmap)

---

## 1. Project Overview & Motivation

Healthcare cost estimation in the United States is notoriously opaque. Both patients and underwriting analysts face significant uncertainty when forecasting annual medical liabilities. 

While machine learning can provide accurate statistical estimates, black-box algorithms frequently suffer from two critical flaws:
1. **Lack of Interpretability:** Stakeholders cannot see *why* an estimate is high or low.
2. **Communication Gap:** Technical metrics such as RMSE, MAE, or logarithmic loss are incomprehensible to non-technical end users.

**HealthCost AI bridges this gap** by combining:
- **Supervised Regression:** Rigorously trained and evaluated pipelines comparing Multiple Linear Regression, Random Forest, and Gradient Boosting.
- **Explainable AI (XAI):** Cooperative game-theoretic SHAP attributions explaining both cohort-wide factors and individual patient cost drivers.
- **LLM Context Injection:** A conversational assistant equipped with the active patient profile, real-time prediction, SHAP breakdown, and verified dataset benchmarks to deliver intuitive explanations with medical and causality guardrails.

---

## 2. End-to-End System Architecture

```mermaid
flowchart TD
    A["Raw Dataset<br/>(1,338 Records)"] --> B["Data Cleaning & Validation<br/>(Deduplication & Schema Checks)"]
    B --> C["Exploratory Data Analysis<br/>(Distributions & Cross-tabs)"]
    B --> D["Preprocessing Pipeline<br/>(StandardScaler + OneHotEncoder)"]
    D --> E["Model Training & Benchmark<br/>(Linear Reg vs RF vs Gradient Boosting)"]
    E --> F["Held-Out Evaluation<br/>(MAE, RMSE, R² on 20% Test Split)"]
    F --> G["Best Model Deployment<br/>(Random Forest Regressor, R² = 0.9018)"]
    G --> H["Prediction Engine<br/>(Charge & Confidence Range)"]
    G --> I["Explainable AI Engine<br/>(SHAP TreeExplainer Waterfall & Importance)"]
    H --> J["Context Assembler<br/>(Profile + Prediction + SHAP + Benchmarks)"]
    I --> J
    J --> K["LLM Conversational Assistant<br/>(OpenAI API + Guardrails / Offline Engine)"]
    H --> L["Interactive Streamlit Dashboard<br/>(Navy/Teal Healthcare Analytics UI)"]
    I --> L
    K --> L
```

---

## 3. Technology Stack

| Layer | Technologies | Purpose |
| :--- | :--- | :--- |
| **Language** | Python 3.10 – 3.14 | Core programming language |
| **Data Processing** | Pandas, NumPy | Data cleaning, wrangling, transformation |
| **Data Visualization** | Matplotlib, Seaborn | Exploratory data analysis, distributions, error plots |
| **Machine Learning** | Scikit-learn, Joblib | Model pipelines, hyperparameter tuning, metrics, serialization |
| **Explainable AI** | SHAP (Shapley Additive exPlanations) | TreeExplainer, global feature importance, local waterfalls |
| **Web Dashboard** | Streamlit | Responsive healthcare analytics web interface |
| **Generative AI** | OpenAI API (or custom endpoint) | Conversational assistant with dynamic context injection |
| **Testing & CI** | Pytest | Automated unit tests across preprocessing, inference, and chat |

---

## 4. Dataset Specifications & Key Findings

The system is trained on the benchmark **Medical Insurance Cost Dataset** (1,338 rows, 7 columns):
- **Features:** `age` (18-64), `sex` (`female`, `male`), `bmi` (15.96-53.13 $kg/m^2$), `children` (0-5), `smoker` (`yes`, `no`), `region` (`northeast`, `northwest`, `southeast`, `southwest`).
- **Target:** `charges` (USD $) — Annual medical expenses billed to the health insurance carrier.

### Key Measured Insights:
1. **Tobacco Smoker Multiplier:** Smokers average **\$32,050.23** compared to **\$8,434.27** for non-smokers (~**3.8x increase**). Smoking accounts for over 60% of target variance.
2. **Non-Linear BMI × Smoker Interaction:**
   - Obese non-smokers ($BMI \ge 30$) average **\$8,809.55**.
   - Obese smokers ($BMI \ge 30$) average **\$41,355.87** (nearly **5x surge**).
3. **Right-Skewed Claims:** Median charge is **\$9,382.03** while mean charge is **\$13,270.42**, driven by severe high-cost outliers up to **\$63,770.43**.

---

## 5. Machine Learning Pipeline & Model Comparison

To prevent data leakage, categorical encoding (`OneHotEncoder(drop='first')`) and continuous feature scaling (`StandardScaler`) are encapsulated within an automated scikit-learn `Pipeline`.

Models were evaluated on a held-out **20% test split** (268 unseen patient records, `random_state=42`):

| Model Architecture | Mean Absolute Error (MAE) | Root Mean Squared Error (RMSE) | R² Score | Evaluation Verdict |
| :--- | :--- | :--- | :--- | :--- |
| **Random Forest Regressor** | **\$2,416.07** | **\$4,248.80** | **0.9018** | 🏆 **Best Model (Selected)** |
| **Gradient Boosting Regressor** | \$2,517.47 | \$4,268.28 | 0.9009 | Close Contender |
| **Linear Regression** | \$4,177.05 | \$5,956.34 | 0.8069 | High Underfitting on Non-linearities |

### Why Random Forest Won:
Linear regression assumes additive, linear feature relationships and struggles with the steep non-linear step change when a beneficiary is both obese and a smoker. Random Forest decision trees naturally partition feature space into non-linear orthogonal splits, capturing interactions without manual feature synthesis.

---

## 6. Explainable AI (SHAP Interpretability)

HealthCost AI implements **SHAP (SHapley Additive exPlanations)** based on cooperative game theory:

### 1. Global Cohort Importance
Computes the mean absolute SHAP value across beneficiaries:
1. `smoker_yes` (~$7,500 average marginal impact)
2. `bmi` (~$1,800 average impact)
3. `age` (~$1,400 average impact)
4. `children`, `region`, and `sex` (<$500 impact)

### 2. Local Patient Attribution
For any predicted beneficiary profile:
$$\text{Predicted Charge} = \text{Base Value } (\$13,018.68) + \sum_{i=1}^{M} \phi_i$$
- **Red Bars (+):** Risk factors pulling the estimate upward (e.g. smoking, advanced age, high BMI).
- **Green Bars (-):** Protective factors lowering expected charges (e.g. non-smoker discount, young age, normal weight).

---

## 7. LLM-Powered Conversational AI Assistant

Unlike static mock bots, HealthCost AI integrates a **real OpenAI API client** equipped with dynamic runtime context injection.

### Dynamic Context Injection:
Every conversation query is passed alongside:
- The active hypothetical user profile
- The exact ML predicted charge & confidence interval
- The local SHAP positive and negative feature drivers
- Deployed model test evaluation metrics (MAE, RMSE, R²)
- Verified empirical dataset benchmarks

### Strict AI Guardrails:
- **No Hallucinations:** Strictly references ground-truth stats and live prediction figures.
- **Correlation $\ne$ Causation:** Clarifies that SHAP values reflect historical associations, not biological cause-and-effect.
- **Medical & Underwriting Disclaimers:** Explicitly warns that estimates do not constitute clinical advice or binding insurance quotes.
- **Graceful Offline Mode:** If no API key is provided, the system executes an intelligent grounded rule-based analytical engine so the user is never stranded.

---

## 8. Interactive Dashboard Features

The dashboard uses a custom healthcare analytics theme (**Navy Dark `#0f2b48`**, **Teal Accent `#0d9488`**, and **Clean White `#ffffff`**):

1. **🏠 Executive Home Dashboard:** Top KPI summary cards, charges density distribution, smoking status comparison boxplot, BMI vs charges interaction scatter plot, age-bracket bar chart, and key dataset insight cards.
2. **🔮 Predict Insurance Charges:** Form with instant BMI categorization pill, real-time prediction card with statistical confidence interval, and a **Side-by-Side Profile Comparison Mode** to inspect cost deltas between two profiles.
3. **📊 Model Benchmarks & Evaluation:** Comparative leaderboard, dual-axis MAE vs R² chart, actual vs predicted scatter plot, residual error histogram, and beginner-friendly metric explanations.
4. **🧠 Explainable AI (SHAP):** Interactive tabs for patient-specific diverging waterfall attributions and cohort-wide global feature rankings.
5. **💬 HealthCost AI Chatbot:** Full chat history, suggested starter prompt pills, clear conversation action, and sidebar API key configuration.

---

## 9. Project Directory Structure

```text
HealthCost-AI/
│
├── app.py                      # Main Streamlit web application
├── requirements.txt            # Compatible pinned dependencies
├── README.md                   # Comprehensive project documentation
├── .gitignore                  # Git ignore rules (secrets, venv, pycache)
├── .env.example                # Example environment variables template
│
├── data/
│   ├── insurance.csv           # Benchmark medical insurance dataset
│   └── README.md               # Dataset dictionary and statistical audit
│
├── notebooks/
│   └── exploratory_analysis.ipynb # Jupyter notebook documenting EDA
│
├── src/
│   ├── __init__.py             # Package marker
│   ├── data_preprocessing.py   # Schema validation, encoding, and scaling
│   ├── train_model.py          # Multi-model training and artifact generation
│   ├── evaluate_model.py       # MAE, RMSE, R² calculations and explanations
│   ├── predict.py              # Model inference and profile comparison
│   ├── explainability.py       # SHAP global & local explainability
│   ├── analytics.py            # Visualizations and aggregate KPI metrics
│   └── llm_chatbot.py          # OpenAI API integration, context injection, guardrails
│
├── models/
│   ├── README.md               # Model benchmarks and training guide
│   ├── best_model.joblib       # Winning Random Forest pipeline
│   ├── linear_regression.joblib# Baseline Linear Regression pipeline
│   ├── random_forest.joblib    # Random Forest Regressor pipeline
│   ├── gradient_boosting.joblib# Gradient Boosting pipeline
│   ├── evaluation_metrics.json # Test metrics and feature metadata
│   └── test_eval_predictions.csv# Held-out actuals vs predictions
│
├── tests/
│   ├── __init__.py             # Test package marker
│   ├── test_preprocessing.py   # Preprocessing and validation tests
│   ├── test_prediction.py      # Inference and profile comparison tests
│   └── test_chatbot.py         # Prompt context, fallback, and chatbot tests
│
└── assets/
    └── README.md               # UI design system tokens and styling rules
```

---

## 10. Installation & Quickstart Guide

### Prerequisites
- Python 3.10+ (tested up to Python 3.14)
- Git

### Step 1: Clone Repository
```bash
git clone https://github.com/your-username/HealthCost-AI.git
cd HealthCost-AI
```

### Step 2: Create and Activate Virtual Environment
```bash
# Windows
python -m venv venv
.\venv\Scripts\activate

# macOS / Linux
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: (Optional) Retrain Models
Trained artifacts are already pre-generated in `models/`. To retrain from scratch:
```bash
python src/train_model.py
```

### Step 5: Launch Streamlit Application
```bash
streamlit run app.py
```
Open your browser at `http://localhost:8501`.

---

## 11. Configuration & Environment Variables

Create a `.env` file in the project root (copied from `.env.example`):
```bash
cp .env.example .env
```

Set your configuration values:
```ini
# OpenAI API Key (or OpenAI-compatible API key e.g. Groq, OpenRouter, LocalAI)
OPENAI_API_KEY=sk-...your-real-key-here...

# Optional: Custom model identifier
OPENAI_MODEL_NAME=gpt-4o-mini

# Optional: Custom API base URL
# OPENAI_BASE_URL=https://api.openai.com/v1
```
*Note: If no API key is provided, the application will seamlessly operate using its built-in offline analytical explanation engine.*

---

## 12. Automated Testing

Run the automated test suite with `pytest`:
```bash
pytest tests/ -v
```

All 13 unit tests cover:
- Data loading and schema integrity
- Numerical boundary checks and categorical domain validation
- Model pipeline serialization and inference output
- Profile comparison calculation and delta computation
- SHAP TreeExplainer integration
- Chatbot context block assembling and graceful offline fallback handling

---

## 13. Limitations & Responsible AI Disclaimer

1. **Target Definition:** Target values represent historical medical insurance charges billed to US health insurers, not internal hospital operational costs or patient copays.
2. **Correlation vs Causation:** High SHAP scores indicate statistical association within the dataset, not biological causation.
3. **Clinical Scope:** HealthCost AI is designed for predictive analytics, educational exploration, and portfolio demonstration. It does **not** provide clinical diagnosis or personalized medical advice.
4. **Underwriting Notice:** Predictions are statistical estimates and do not represent formal insurance contracts, quotes, or binding underwriting decisions.

---

## 14. Future Roadmap

- [ ] Add support for polynomial features and interaction term discovery in linear baselines.
- [ ] Implement XGBoost and LightGBM model comparisons.
- [ ] Integrate Counterfactual Explanations (What-If analysis with DiCE).
- [ ] Export personalized PDF analytics reports for patients and underwriters.

---

## 👨‍💻 Author & Portfolio Contact
- **Project:** HealthCost AI
- **Repository:** [GitHub](https://github.com/)
- **License:** MIT License
