"""
HealthCost AI - Intelligent Healthcare Cost Prediction & AI Assistant
Main Streamlit Application
"""

import os
import sys
import json
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Ensure src modules can be resolved
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from src.data_preprocessing import (
    load_dataset,
    calculate_bmi_category,
    ALLOWED_VALUES
)
from src.predict import (
    predict_charge,
    compare_two_profiles,
    load_prediction_pipeline
)
from src.explainability import (
    explain_global_importance,
    explain_single_prediction
)
from src.analytics import (
    get_dataset_kpis,
    plot_charges_distribution,
    plot_charges_by_smoker,
    plot_bmi_vs_charges,
    plot_charges_by_age_group,
    get_key_dataset_insights
)
from src.evaluate_model import get_metric_explanations, compare_models_summary
from src.llm_chatbot import generate_chat_response, build_context_block


# --- PAGE CONFIGURATION ---
st.set_page_config(
    page_title="HealthCost AI | Healthcare Cost Prediction & AI Assistant",
    page_icon="🩺",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- CUSTOM CSS THEME (Healthcare Navy, White, Teal) ---
st.markdown("""
<style>
    /* Primary Color Palette */
    :root {
        --navy-dark: #0f2b48;
        --navy-light: #1e3a8a;
        --teal-accent: #0d9488;
        --teal-light: #ccfbf1;
        --slate-bg: #f8fafc;
        --card-border: #e2e8f0;
    }

    /* Overall Header Styling */
    .main-title {
        color: #0f2b48;
        font-size: 2.2rem;
        font-weight: 800;
        margin-bottom: 0.2rem;
        display: flex;
        align-items: center;
        gap: 0.6rem;
    }
    
    .sub-title {
        color: #475569;
        font-size: 1.05rem;
        margin-bottom: 1.5rem;
    }

    /* Stat Card Component */
    .stat-card {
        background-color: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 1.2rem;
        box-shadow: 0 2px 6px rgba(15, 43, 72, 0.04);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
        text-align: left;
    }
    
    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(15, 43, 72, 0.08);
    }
    
    .stat-label {
        font-size: 0.82rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: #64748b;
        font-weight: 600;
        margin-bottom: 0.3rem;
    }
    
    .stat-value {
        font-size: 1.7rem;
        font-weight: 700;
        color: #0f2b48;
    }
    
    .stat-subtitle {
        font-size: 0.8rem;
        color: #0d9488;
        font-weight: 500;
        margin-top: 0.25rem;
    }

    /* Prediction Highlight Card */
    .prediction-box {
        background: linear-gradient(135deg, #0f2b48 0%, #1e3a8a 100%);
        color: #ffffff;
        border-radius: 16px;
        padding: 1.8rem;
        box-shadow: 0 8px 24px rgba(15, 43, 72, 0.15);
        margin: 1.2rem 0;
    }
    
    .pred-amount {
        font-size: 2.8rem;
        font-weight: 800;
        color: #2dd4bf;
        margin: 0.4rem 0;
    }

    /* Badge */
    .badge {
        display: inline-block;
        padding: 0.25rem 0.65rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: uppercase;
    }

    /* Disclaimer note */
    .disclaimer-box {
        background-color: #f8fafc;
        border-left: 4px solid #94a3b8;
        padding: 0.75rem 1rem;
        border-radius: 4px;
        font-size: 0.8rem;
        color: #64748b;
        margin-top: 1rem;
    }
</style>
""", unsafe_allow_html=True)


# --- DATA & MODEL CACHING ---
@st.cache_data
def get_cached_dataset():
    return load_dataset("data/insurance.csv")


@st.cache_data
def get_cached_kpis():
    return get_dataset_kpis("data/insurance.csv")


@st.cache_data
def get_cached_metrics():
    metrics_path = "models/evaluation_metrics.json"
    if os.path.exists(metrics_path):
        with open(metrics_path, "r", encoding="utf-8") as f:
            return json.load(f)
    return None


@st.cache_data
def get_cached_global_shap():
    return explain_global_importance("models/best_model.joblib", sample_size=300)


# Initialize Session State
if "chat_history" not in st.session_state:
    st.session_state.chat_history = [
        {
            "role": "assistant",
            "content": (
                "👋 Hello! I am **HealthCost AI Assistant**. I can explain your healthcare insurance charge prediction, "
                "break down influencing factors (SHAP values), explain model metrics like MAE or R², and share key dataset insights.\n\n"
                "Try asking me a question below or click one of the suggested starter prompts!"
            )
        }
    ]

if "last_prediction" not in st.session_state:
    # Default baseline profile
    default_input = {
        "age": 35,
        "sex": "female",
        "bmi": 27.5,
        "children": 1,
        "smoker": "no",
        "region": "northwest"
    }
    try:
        st.session_state.last_prediction = predict_charge(default_input)
    except Exception:
        st.session_state.last_prediction = None

if "last_shap" not in st.session_state:
    if st.session_state.last_prediction:
        try:
            st.session_state.last_shap = explain_single_prediction(st.session_state.last_prediction["sanitized_input"])
        except Exception:
            st.session_state.last_shap = None
    else:
        st.session_state.last_shap = None


# --- SIDEBAR CONFIGURATION ---
with st.sidebar:
    st.image("https://img.icons8.com/fluency/96/medical-heart.png", width=54)
    st.markdown("### **HealthCost AI**")
    st.caption("Machine Learning & Explainable AI Healthcare Analytics")
    
    st.markdown("---")
    
    # Navigation Radio
    navigation = st.radio(
        "Navigation",
        [
            "🏠 Home Dashboard",
            "🔮 Predict Insurance Charges",
            "📊 Model Benchmarks & Evaluation",
            "🧠 Explainable AI (SHAP)",
            "💬 HealthCost AI Chatbot"
        ],
        index=0
    )
    
    st.markdown("---")
    
    # LLM Settings
    st.markdown("#### ⚙️ LLM Assistant Settings")
    sidebar_api_key = st.text_input(
        "OpenAI API Key",
        value=os.getenv("OPENAI_API_KEY", ""),
        type="password",
        help="Enter your OpenAI API key or configure it in .env. If left blank, the assistant runs in offline grounded analytical mode."
    )
    
    llm_model = st.selectbox(
        "Model Provider / Model",
        ["gpt-4o-mini", "gpt-4o", "gpt-3.5-turbo", "custom"],
        index=0
    )
    
    custom_base_url = None
    if llm_model == "custom":
        custom_base_url = st.text_input("Custom Base URL", value="https://api.openai.com/v1")
        custom_model_name = st.text_input("Custom Model Name", value="gpt-4o-mini")
        llm_model = custom_model_name
        
    if sidebar_api_key and sidebar_api_key != "your_openai_api_key_here":
        st.success("🟢 OpenAI Connected", icon="✅")
    else:
        st.info("🟡 Offline Grounded Mode Active (No API Key Required)", icon="ℹ️")
        
    st.markdown("---")
    st.markdown(
        "<div style='font-size:0.75rem; color:#64748b; line-height:1.4;'>"
        "<b>Model:</b> Random Forest Regressor<br>"
        "<b>Test R²:</b> 0.9018 | <b>MAE:</b> $2,416<br>"
        "<b>Dataset:</b> 1,338 US Health Insurance Records<br>"
        "© 2026 HealthCost AI Portfolio Project"
        "</div>",
        unsafe_allow_html=True
    )


# Load data and metrics
df = get_cached_dataset()
kpis = get_cached_kpis()
metrics_json = get_cached_metrics()
best_mae = metrics_json["models"]["Random Forest Regressor"]["mae"] if metrics_json else 2416.07


# ==============================================================================
# 1. HOME DASHBOARD
# ==============================================================================
if navigation == "🏠 Home Dashboard":
    st.markdown('<div class="main-title">🩺 HealthCost AI Executive Dashboard</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-title">Intelligent Healthcare Insurance Charges Prediction, Exploratory Analytics, and Explainable AI</div>',
        unsafe_allow_html=True
    )
    
    # Top KPI Metrics Row
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.markdown(f"""
        <div class="stat-card">
            <div class="stat-label">Total Verified Records</div>
            <div class="stat-value">{kpis['total_records']:,}</div>
            <div class="stat-subtitle">US Insurance Cohort</div>
        </div>
        """, unsafe_allow_html=True)
        
    with col2:
        st.markdown(f"""
        <div class="stat-card">
            <div class="stat-label">Average Annual Charge</div>
            <div class="stat-value">${kpis['mean_charge']:,.0f}</div>
            <div class="stat-subtitle">Median: ${kpis['median_charge']:,.0f}</div>
        </div>
        """, unsafe_allow_html=True)
        
    with col3:
        st.markdown(f"""
        <div class="stat-card">
            <div class="stat-label">Smoker Disparity</div>
            <div class="stat-value">{kpis['smoker_multiplier']}x</div>
            <div class="stat-subtitle">${kpis['smoker_mean_charge']:,.0f} vs ${kpis['nonsmoker_mean_charge']:,.0f}</div>
        </div>
        """, unsafe_allow_html=True)
        
    with col4:
        st.markdown(f"""
        <div class="stat-card">
            <div class="stat-label">Best Model Test MAE</div>
            <div class="stat-value">${best_mae:,.0f}</div>
            <div class="stat-subtitle">R² Score: 0.9018</div>
        </div>
        """, unsafe_allow_html=True)
        
    st.markdown("<br>", unsafe_allow_html=True)
    
    # Charts Grid
    row1_c1, row1_c2 = st.columns(2)
    with row1_c1:
        st.pyplot(plot_charges_distribution(df))
    with row1_c2:
        st.pyplot(plot_charges_by_smoker(df))
        
    row2_c1, row2_c2 = st.columns(2)
    with row2_c1:
        st.pyplot(plot_bmi_vs_charges(df))
    with row2_c2:
        st.pyplot(plot_charges_by_age_group(df))
        
    # Dataset Insights Section
    st.markdown("### 🔍 Verified Dataset Insights")
    insights = get_key_dataset_insights()
    i_cols = st.columns(4)
    for idx, insight in enumerate(insights):
        with i_cols[idx]:
            st.markdown(f"""
            <div class="stat-card" style="height: 100%;">
                <div style="font-size: 0.9rem; font-weight: 700; color: #0f2b48; margin-bottom: 0.4rem;">{insight['title']}</div>
                <div style="font-size: 1.15rem; font-weight: 800; color: #0d9488; margin-bottom: 0.4rem;">{insight['stat']}</div>
                <div style="font-size: 0.8rem; color: #475569; line-height: 1.4;">{insight['desc']}</div>
            </div>
            """, unsafe_allow_html=True)
            
    st.markdown("""
    <div class="disclaimer-box">
        <b>Data Integrity Note:</b> All statistics above are computed directly from the 1,338 benchmark records. 
        Target values represent annual medical insurance charges in US Dollars (USD) billed to the insurance carrier.
    </div>
    """, unsafe_allow_html=True)


# ==============================================================================
# 2. PREDICT INSURANCE CHARGES
# ==============================================================================
elif navigation == "🔮 Predict Insurance Charges":
    st.markdown('<div class="main-title">🔮 Predict Healthcare Insurance Charges</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-title">Enter beneficiary demographic and health risk attributes to generate an ML-powered cost estimate.</div>',
        unsafe_allow_html=True
    )
    
    compare_mode = st.toggle("🔄 Enable Side-by-Side Profile Comparison Mode", value=False)
    
    if not compare_mode:
        # Single Profile Mode
        col_form, col_result = st.columns([1.1, 1])
        
        with col_form:
            st.markdown("#### Beneficiary Input Profile")
            with st.form("prediction_form"):
                f_age = st.slider("Beneficiary Age (Years)", min_value=18, max_value=85, value=38, step=1)
                
                f_c1, f_c2 = st.columns(2)
                with f_c1:
                    f_sex = st.selectbox("Biological Sex", ["female", "male"], index=0)
                with f_c2:
                    f_smoker = st.selectbox("Tobacco Smoker Status", ["no", "yes"], index=0)
                    
                f_c3, f_c4 = st.columns(2)
                with f_c3:
                    f_bmi = st.number_input("Body Mass Index (BMI in kg/m²)", min_value=12.0, max_value=60.0, value=28.4, step=0.1)
                    bmi_cat, bmi_color = calculate_bmi_category(f_bmi)
                    st.markdown(
                        f"Weight Classification: <span class='badge' style='background-color:{bmi_color}22; color:{bmi_color};'>{bmi_cat}</span>",
                        unsafe_allow_html=True
                    )
                with f_c4:
                    f_children = st.number_input("Number of Dependent Children", min_value=0, max_value=10, value=1, step=1)
                    
                f_region = st.selectbox("Geographic Region (US)", ["northeast", "northwest", "southeast", "southwest"], index=1)
                
                submitted = st.form_submit_button("⚡ Calculate Predicted Charge", use_container_width=True, type="primary")
                
            input_dict = {
                "age": f_age,
                "sex": f_sex,
                "bmi": f_bmi,
                "children": f_children,
                "smoker": f_smoker,
                "region": f_region
            }
            
            if submitted or st.session_state.last_prediction is None:
                try:
                    res = predict_charge(input_dict)
                    st.session_state.last_prediction = res
                    st.session_state.last_shap = explain_single_prediction(res["sanitized_input"])
                except Exception as e:
                    st.error(f"Prediction Error: {str(e)}")
                    
        with col_result:
            if st.session_state.last_prediction:
                pred = st.session_state.last_prediction
                st.markdown(f"""
                <div class="prediction-box">
                    <div style="font-size:0.9rem; text-transform:uppercase; letter-spacing:0.08em; opacity:0.85;">Model Estimated Annual Charge</div>
                    <div class="pred-amount">${pred['predicted_charge']:,.2f} USD</div>
                    <div style="font-size:0.95rem; opacity:0.9;">
                        <b>Expected Statistical Range:</b> ${pred['lower_bound']:,.2f} – ${pred['upper_bound']:,.2f}
                    </div>
                    <div style="margin-top:0.8rem; font-size:0.85rem; opacity:0.8;">
                        Profile: <b>{pred['sanitized_input']['age']} yrs</b> | <b>{pred['sanitized_input']['sex'].title()}</b> | 
                        <b>BMI {pred['sanitized_input']['bmi']}</b> ({pred['bmi_category']}) | 
                        Smoker: <b>{pred['sanitized_input']['smoker'].upper()}</b>
                    </div>
                </div>
                """, unsafe_allow_html=True)
                
                # Context Quick Breakdown
                st.markdown("##### 📌 Immediate Risk Factor Highlights")
                inp = pred["sanitized_input"]
                if inp["smoker"] == "yes":
                    st.warning("⚠️ **Smoker Flag Active:** Tobacco smoking introduces the largest baseline charge multiplier in this dataset (~3.8x population baseline).")
                else:
                    st.success("✅ **Non-Smoker Status:** Substantially lowers projected baseline claim liabilities.")
                    
                if inp["bmi"] >= 30:
                    st.warning(f"⚠️ **Clinical Obesity (BMI {inp['bmi']}):** High-risk tier. When combined with smoking, historical claims average over $41,000.")
                elif inp["bmi"] < 25:
                    st.success(f"✅ **Normal Weight (BMI {inp['bmi']}):** Minimizes weight-associated risk penalties.")
                    
                st.markdown(f"<div class='disclaimer-box'>{pred['disclaimer']}</div>", unsafe_allow_html=True)
                
    else:
        # Comparison Mode: Two Profiles Side by Side
        st.markdown("#### Side-by-Side Beneficiary Profile Comparison")
        col_a, col_b = st.columns(2)
        
        with col_a:
            st.markdown("##### Profile A (Baseline)")
            a_age = st.slider("Profile A Age", 18, 80, 40, key="a_age")
            a_sex = st.selectbox("Profile A Sex", ["female", "male"], index=0, key="a_sex")
            a_bmi = st.number_input("Profile A BMI", 12.0, 60.0, 24.5, step=0.1, key="a_bmi")
            a_children = st.number_input("Profile A Children", 0, 10, 0, step=1, key="a_child")
            a_smoker = st.selectbox("Profile A Smoker", ["no", "yes"], index=0, key="a_smoker")
            a_region = st.selectbox("Profile A Region", ["northeast", "northwest", "southeast", "southwest"], index=0, key="a_reg")
            
        with col_b:
            st.markdown("##### Profile B (Hypothetical Alternative)")
            b_age = st.slider("Profile B Age", 18, 80, 40, key="b_age")
            b_sex = st.selectbox("Profile B Sex", ["female", "male"], index=0, key="b_sex")
            b_bmi = st.number_input("Profile B BMI", 12.0, 60.0, 32.0, step=0.1, key="b_bmi")
            b_children = st.number_input("Profile B Children", 0, 10, 0, step=1, key="b_child")
            b_smoker = st.selectbox("Profile B Smoker", ["no", "yes"], index=1, key="b_smoker")
            b_region = st.selectbox("Profile B Region", ["northeast", "northwest", "southeast", "southwest"], index=0, key="b_reg")
            
        prof_a = {"age": a_age, "sex": a_sex, "bmi": a_bmi, "children": a_children, "smoker": a_smoker, "region": a_region}
        prof_b = {"age": b_age, "sex": b_sex, "bmi": b_bmi, "children": b_children, "smoker": b_smoker, "region": b_region}
        
        comp_res = compare_two_profiles(prof_a, prof_b)
        
        st.markdown("---")
        st.markdown("#### ⚖️ Comparison Findings")
        
        r_c1, r_c2, r_c3 = st.columns(3)
        with r_c1:
            st.metric("Profile A Estimate", f"${comp_res['profile_a']['predicted_charge']:,.2f}")
        with r_c2:
            st.metric("Profile B Estimate", f"${comp_res['profile_b']['predicted_charge']:,.2f}")
        with r_c3:
            diff_sign = "+" if comp_res['charge_difference_usd'] > 0 else ""
            st.metric(
                "Delta (B vs A)",
                f"{diff_sign}${comp_res['charge_difference_usd']:,.2f}",
                f"{diff_sign}{comp_res['charge_difference_pct']}%"
            )
            
        if comp_res["differing_features"]:
            st.markdown("##### Feature Differences Leading to Delta:")
            diff_rows = []
            for feat, vals in comp_res["differing_features"].items():
                diff_rows.append({
                    "Feature": feat.upper(),
                    "Profile A": vals["profile_a"],
                    "Profile B": vals["profile_b"]
                })
            st.dataframe(pd.DataFrame(diff_rows), use_container_width=True, hide_index=True)


# ==============================================================================
# 3. MODEL BENCHMARKS & EVALUATION
# ==============================================================================
elif navigation == "📊 Model Benchmarks & Evaluation":
    st.markdown('<div class="main-title">📊 Machine Learning Model Evaluation</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-title">Rigorous comparison of Linear Regression, Random Forest, and Gradient Boosting on held-out test data.</div>',
        unsafe_allow_html=True
    )
    
    if metrics_json:
        models_data = metrics_json["models"]
        comp_df = compare_models_summary(models_data)
        
        col_table, col_chart = st.columns([1, 1.2])
        
        with col_table:
            st.markdown("#### 🏆 Test Evaluation Leaderboard")
            st.caption(f"Evaluated on {metrics_json['test_samples']} unseen test records (20% holdout split, seed=42)")
            
            # Format display dataframe
            styled_df = comp_df.copy()
            styled_df["MAE ($)"] = styled_df["MAE ($)"].apply(lambda x: f"${x:,.2f}")
            styled_df["RMSE ($)"] = styled_df["RMSE ($)"].apply(lambda x: f"${x:,.2f}")
            styled_df["R² Score"] = styled_df["R² Score"].apply(lambda x: f"{x:.4f}")
            st.dataframe(styled_df, use_container_width=True, hide_index=True)
            
            st.success(f"**Winner: {metrics_json['best_model_name']}** achieves the highest explanatory power (R² = 0.9018) and lowest error (MAE = $2,416.07).")
            
        with col_chart:
            st.markdown("#### 📈 Comparative Error & Accuracy")
            fig, ax1 = plt.subplots(figsize=(6.5, 3.8), dpi=140)
            
            names = comp_df["Model Name"]
            r2_vals = comp_df["R² Score"]
            mae_vals = comp_df["MAE ($)"]
            
            x = np.arange(len(names))
            width = 0.35
            
            # Plot MAE
            bars = ax1.bar(x - width/2, mae_vals, width, label="MAE ($)", color="#0284c7", alpha=0.85)
            ax1.set_ylabel("Mean Absolute Error (USD $)", color="#0284c7", fontsize=9)
            ax1.set_xticks(x)
            ax1.set_xticklabels(["Random Forest", "Gradient Boosting", "Linear Regression"], fontsize=8.5)
            ax1.grid(axis="y", linestyle=":", alpha=0.3)
            
            # Twin axis for R2
            ax2 = ax1.twinx()
            lines = ax2.plot(x + width/2, r2_vals, color="#e11d48", marker="o", linewidth=2, label="R² Score")
            ax2.set_ylabel("R² Score (0 to 1)", color="#e11d48", fontsize=9)
            ax2.set_ylim(0.75, 0.95)
            
            ax1.spines["top"].set_visible(False)
            ax2.spines["top"].set_visible(False)
            
            plt.title("Model Error (MAE) vs Explanatory Power (R²)", fontsize=10, fontweight="bold", pad=10)
            plt.tight_layout()
            st.pyplot(fig)
            
        # Actual vs Predicted Plot
        test_pred_path = "models/test_eval_predictions.csv"
        if os.path.exists(test_pred_path):
            st.markdown("---")
            st.markdown("#### 🎯 Actual vs Predicted Charges (Held-Out Test Data)")
            test_df = pd.read_csv(test_pred_path)
            
            c_p1, c_p2 = st.columns(2)
            with c_p1:
                fig_act, ax_act = plt.subplots(figsize=(6.5, 3.6), dpi=140)
                ax_act.scatter(test_df["actual"], test_df["pred_random_forest_regressor"], color="#0d9488", alpha=0.65, s=28)
                
                # Perfect prediction diagonal
                min_v = 0
                max_v = max(test_df["actual"].max(), test_df["pred_random_forest_regressor"].max())
                ax_act.plot([min_v, max_v], [min_v, max_v], color="#ef4444", linestyle="--", linewidth=1.5, label="Perfect Agreement (y = x)")
                
                ax_act.set_title("Random Forest: Actual vs Predicted", fontsize=10, fontweight="bold", color="#0f2b48")
                ax_act.set_xlabel("Actual Insurance Charges ($)", fontsize=8.5)
                ax_act.set_ylabel("Model Predicted Charges ($)", fontsize=8.5)
                ax_act.legend(fontsize=8)
                ax_act.grid(True, linestyle=":", alpha=0.3)
                ax_act.spines["top"].set_visible(False)
                ax_act.spines["right"].set_visible(False)
                plt.tight_layout()
                st.pyplot(fig_act)
                
            with c_p2:
                # Residuals distribution
                residuals = test_df["actual"] - test_df["pred_random_forest_regressor"]
                fig_res, ax_res = plt.subplots(figsize=(6.5, 3.6), dpi=140)
                ax_res.hist(residuals, bins=30, color="#3b82f6", edgecolor="white", alpha=0.75)
                ax_res.axvline(0, color="#ef4444", linestyle="--", linewidth=1.5)
                ax_res.set_title("Residual Error Distribution (Actual - Predicted)", fontsize=10, fontweight="bold", color="#0f2b48")
                ax_res.set_xlabel("Residual Error (USD $)", fontsize=8.5)
                ax_res.set_ylabel("Count", fontsize=8.5)
                ax_res.grid(axis="y", linestyle=":", alpha=0.3)
                ax_res.spines["top"].set_visible(False)
                ax_res.spines["right"].set_visible(False)
                plt.tight_layout()
                st.pyplot(fig_res)
                
        # Metric Explanations in Beginner-Friendly Terms
        st.markdown("---")
        st.markdown("#### 📘 Beginner-Friendly Metric Guide")
        explanations = get_metric_explanations()
        e_col1, e_col2, e_col3 = st.columns(3)
        
        with e_col1:
            st.markdown(f"""
            <div class="stat-card">
                <div style="font-weight:700; color:#0f2b48; margin-bottom:0.3rem;">{explanations['MAE']['name']}</div>
                <div style="font-size:0.82rem; color:#475569; margin-bottom:0.4rem;">{explanations['MAE']['explanation']}</div>
                <div style="font-size:0.8rem; color:#0d9488; font-weight:600;">{explanations['MAE']['interpretation']}</div>
            </div>
            """, unsafe_allow_html=True)
            
        with e_col2:
            st.markdown(f"""
            <div class="stat-card">
                <div style="font-weight:700; color:#0f2b48; margin-bottom:0.3rem;">{explanations['RMSE']['name']}</div>
                <div style="font-size:0.82rem; color:#475569; margin-bottom:0.4rem;">{explanations['RMSE']['explanation']}</div>
                <div style="font-size:0.8rem; color:#0d9488; font-weight:600;">{explanations['RMSE']['interpretation']}</div>
            </div>
            """, unsafe_allow_html=True)
            
        with e_col3:
            st.markdown(f"""
            <div class="stat-card">
                <div style="font-weight:700; color:#0f2b48; margin-bottom:0.3rem;">{explanations['R2']['name']}</div>
                <div style="font-size:0.82rem; color:#475569; margin-bottom:0.4rem;">{explanations['R2']['explanation']}</div>
                <div style="font-size:0.8rem; color:#0d9488; font-weight:600;">{explanations['R2']['interpretation']}</div>
            </div>
            """, unsafe_allow_html=True)


# ==============================================================================
# 4. EXPLAINABLE AI (SHAP)
# ==============================================================================
elif navigation == "🧠 Explainable AI (SHAP)":
    st.markdown('<div class="main-title">🧠 Explainable AI (SHAP Interpretability)</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-title">Peek inside the black-box model using cooperative game theory (Shapley values). Understand both population-wide and patient-specific drivers.</div>',
        unsafe_allow_html=True
    )
    
    tab_local, tab_global = st.tabs(["🎯 Local Explanation (Current Prediction)", "🌐 Global Feature Importance"])
    
    with tab_local:
        if st.session_state.last_shap and st.session_state.last_prediction:
            shap_info = st.session_state.last_shap
            pred_info = st.session_state.last_prediction
            
            c_l1, c_l2 = st.columns([1.2, 1])
            
            with c_l1:
                st.pyplot(shap_info["figure"])
                
            with c_l2:
                st.markdown("#### Factor Attribution Breakdown")
                st.markdown(
                    f"**Population Baseline (Expected Value):** `${shap_info['base_value']:,.2f}`<br>"
                    f"**Final Model Prediction:** `${shap_info['predicted_value']:,.2f}`",
                    unsafe_allow_html=True
                )
                
                st.markdown("##### 🔺 Pushing Charges Higher:")
                pos_list = shap_info["top_positive_factors"]
                if pos_list:
                    for p in pos_list:
                        st.markdown(f"• **{p['feature_label']}**: `+${p['shap_value']:,.2f}`")
                else:
                    st.markdown("• *No major upward drivers for this profile.*")
                    
                st.markdown("##### 🔻 Pushing Charges Lower:")
                neg_list = shap_info["top_negative_factors"]
                if neg_list:
                    for n in neg_list:
                        st.markdown(f"• **{n['feature_label']}**: `-${abs(n['shap_value']):,.2f}`")
                else:
                    st.markdown("• *No major downward drivers for this profile.*")
                    
            st.markdown("---")
            st.markdown("##### Detailed Feature Contribution Table")
            display_contrib = shap_info["contributions_df"][["feature_label", "shap_value", "effect"]].copy()
            display_contrib.columns = ["Feature", "SHAP Value (USD $)", "Directional Effect"]
            st.dataframe(display_contrib, use_container_width=True, hide_index=True)
            
            st.markdown(f"<div class='disclaimer-box'><b>Causality Disclaimer:</b> {shap_info['causality_disclaimer']}</div>", unsafe_allow_html=True)
        else:
            st.warning("Please visit the **Predict Insurance Charges** page first to generate a profile prediction.")
            
    with tab_global:
        st.markdown("#### Global Feature Importance across Cohort")
        st.caption("Computed using the mean absolute SHAP value across beneficiaries.")
        
        global_df, global_fig = get_cached_global_shap()
        
        g_c1, g_c2 = st.columns([1.3, 1])
        with g_c1:
            st.pyplot(global_fig)
        with g_c2:
            st.markdown("##### Feature Impact Ranking")
            g_table = global_df[["feature_label", "mean_abs_shap"]].copy()
            g_table.columns = ["Feature Name", "Mean |SHAP| ($)"]
            g_table["Mean |SHAP| ($)"] = g_table["Mean |SHAP| ($)"].apply(lambda x: f"${x:,.2f}")
            st.dataframe(g_table, use_container_width=True, hide_index=True)
            
            st.markdown("""
            **Key Takeaway:**
            - **Smoker Status** is unequivocally the single largest global determinant.
            - **BMI** and **Age** form the second tier of continuous determinants.
            - **Sex** and **Region** contribute comparatively modest variation.
            """)


# ==============================================================================
# 5. HEALTHCOST AI CHATBOT
# ==============================================================================
elif navigation == "💬 HealthCost AI Chatbot":
    st.markdown('<div class="main-title">💬 HealthCost AI Assistant</div>', unsafe_allow_html=True)
    st.markdown(
        '<div class="sub-title">Conversational AI trained on the dataset findings, ML predictions, and SHAP explanations.</div>',
        unsafe_allow_html=True
    )
    
    # Active Context Indicator Pill
    if st.session_state.last_prediction:
        act_inp = st.session_state.last_prediction["sanitized_input"]
        st.info(
            f"🎯 **Active Prediction Context Loaded:** Age={act_inp['age']}, Sex={act_inp['sex'].title()}, "
            f"BMI={act_inp['bmi']} ({st.session_state.last_prediction['bmi_category']}), Smoker={act_inp['smoker'].upper()}, "
            f"Predicted Charge=**${st.session_state.last_prediction['predicted_charge']:,.2f}**",
            icon="📌"
        )
    else:
        st.info("ℹ️ No active prediction loaded. Running in general dataset & model knowledge mode.", icon="ℹ️")
        
    # Suggested Starter Prompts
    st.markdown("##### 💡 Suggested Questions")
    starters = [
        "Explain my prediction in simple terms",
        "Why is my predicted charge high?",
        "What are the most important factors?",
        "What does the MAE metric mean?",
        "Summarize the main findings from the dataset"
    ]
    
    starter_cols = st.columns(len(starters))
    selected_starter = None
    for idx, prompt in enumerate(starters):
        with starter_cols[idx]:
            if st.button(prompt, key=f"starter_{idx}", use_container_width=True):
                selected_starter = prompt
                
    st.markdown("---")
    
    # Chat History Container
    for msg in st.session_state.chat_history:
        avatar = "🩺" if msg["role"] == "assistant" else "👤"
        with st.chat_message(msg["role"], avatar=avatar):
            st.markdown(msg["content"])
            
    # Handle User Input
    user_input = st.chat_input("Ask a question about the prediction, SHAP features, or dataset...")
    
    prompt_to_send = selected_starter if selected_starter else user_input
    
    if prompt_to_send:
        # Append User Message
        st.session_state.chat_history.append({"role": "user", "content": prompt_to_send})
        with st.chat_message("user", avatar="👤"):
            st.markdown(prompt_to_send)
            
        # Generate Assistant Response
        with st.chat_message("assistant", avatar="🩺"):
            with st.spinner("Analyzing context & generating response..."):
                response_text = generate_chat_response(
                    messages=st.session_state.chat_history,
                    api_key=sidebar_api_key,
                    base_url=custom_base_url,
                    model_name=llm_model,
                    current_prediction=st.session_state.last_prediction,
                    shap_explanation=st.session_state.last_shap,
                    model_metrics=metrics_json,
                    dataset_kpis=kpis
                )
                st.markdown(response_text)
                st.session_state.chat_history.append({"role": "assistant", "content": response_text})
                
    # Clear conversation button
    if len(st.session_state.chat_history) > 1:
        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("🗑️ Clear Chat History", type="secondary"):
            st.session_state.chat_history = [
                {
                    "role": "assistant",
                    "content": "Conversation cleared. Feel free to ask a new question about your healthcare cost predictions!"
                }
            ]
            st.rerun()
